﻿using System;
using System.Windows.Forms;
using System.Net.NetworkInformation;
using System.Management;
using System.Diagnostics;
using System.Threading;
using System.Diagnostics.Tracing;

namespace UIDelay
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private static EventSource log = new EventSource("UIDelayProvider");

        //Simulate netwok dependency
        private void PingServer()
        {
            
            Ping p = new Ping();
            try
            {
                PingReply reply = p.Send("www.microsoft.com", 3000);
            }
            catch { }
        }

        //Simulate CPU intensive task
        private void ExecuteCPUIntensiveOperation()
        {
            DateTime endTime = DateTime.Now.AddSeconds(10);
            int i = 0;
            while (DateTime.Now < endTime) { i++; }
        }

        private void ExecuteWMICall()
        {
            // create management class object
            ManagementClass mc = new ManagementClass("Win32_ComputerSystem");

            //collection to store all management objects
            ManagementObjectCollection moc = mc.GetInstances();

            if (moc.Count != 0)
            {
                foreach (ManagementObject mo in mc.GetInstances())
                {
                    var stopwatch = Stopwatch.StartNew();
                    Thread.Sleep(5000);
                    stopwatch.Stop();

                    textBox1.Text = "Done!";
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            log.Write("PingServer", new EventSourceOptions { Opcode = EventOpcode.Start });
            PingServer();
            log.Write("PingServer", new EventSourceOptions { Opcode = EventOpcode.Stop });

            log.Write("CPUFunction", new EventSourceOptions { Opcode = EventOpcode.Start });
            ExecuteCPUIntensiveOperation();
            log.Write("CPUFunction", new EventSourceOptions { Opcode = EventOpcode.Stop });

            log.Write("ExecuteWMICall", new EventSourceOptions { Opcode = EventOpcode.Start });
            ExecuteWMICall();
            log.Write("ExecuteWMICall", new EventSourceOptions { Opcode = EventOpcode.Stop });

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


    }
}
